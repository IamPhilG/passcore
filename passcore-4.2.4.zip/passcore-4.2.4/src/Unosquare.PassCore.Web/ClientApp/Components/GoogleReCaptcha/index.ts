import GoogleReCaptcha from './GoogleReCaptcha';
import loadReCaptcha from './loadReCaptcha';

export { loadReCaptcha };
export default GoogleReCaptcha;
