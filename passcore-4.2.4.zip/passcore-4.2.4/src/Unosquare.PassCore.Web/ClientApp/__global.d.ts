export {};

declare global {
    // tslint:disable-next-line
    interface Window {
        grecaptcha: any;
    }
}
