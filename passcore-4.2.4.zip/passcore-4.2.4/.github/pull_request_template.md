**PassCore Server**
- OS: [Windows | Linux | macOS]
- Provider: [Active Directory | LDAP]

**Describe the intention of the PR** 
A clear and concise description of what the pull request is.
